<?php
	
	$mysqli = new mysqli("localhost", "root", "", "rol");
	
?>
